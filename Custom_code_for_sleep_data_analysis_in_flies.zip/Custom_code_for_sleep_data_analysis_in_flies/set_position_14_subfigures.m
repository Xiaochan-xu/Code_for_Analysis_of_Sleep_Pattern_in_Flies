%% this code is for setting positions of sub figures
x_gap = 0.02;
y_gap = 0.05;
width = 0.12;
hight = 0.4;
x_0 = 0.02;
y_0 = 0.05;
for i = 1:14
    row_i = floor((i-0.5)/7)+1;
    col_i = i - (row_i-1)*7;
    h(i).Position = [x_0+(col_i-1)*(width+x_gap),y_0+(2-row_i)*(hight+y_gap),width,hight];    
end