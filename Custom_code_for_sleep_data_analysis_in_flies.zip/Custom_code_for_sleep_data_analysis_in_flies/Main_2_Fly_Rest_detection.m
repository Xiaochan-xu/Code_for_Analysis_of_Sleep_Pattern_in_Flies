%% Main code for rest interval detection from the trajectory. 
function [REST]= Main_2_Fly_Rest_detection(path)

% input: path, the detected locations of the fly along time.
% output: rest interval, 4 col matrix (rest start frame, rest end frame, 0, duration);
load('./example_datasets/path.mat');

%% parameters
smooth_span = 0;
grid_width_rest = 0.5;  % The range of the subpath of rest shold be limited in a same rectangle with grid_width_rest*grid_width_rest
slide_width = 0.2;      % do not need to change
N_least = 25;           % At least 25 data points should be in the detected rest intervals

%% smooth the path with average method
if smooth_span > 0
   smooth_path(:,1) = smooth(path(:,1),smooth_span);
   smooth_path(:,2) = smooth(path(:,2),smooth_span);
else
   smooth_path(:,1) = path(:,1);
   smooth_path(:,2) = path(:,2);
end

%% merge rest points
Slide = 1/slide_width;
T = zeros(size(smooth_path,1),Slide^2);
w = 1;
for j1 = 0:Slide-1
    for j2 = 0:Slide-1
        x0 = min(smooth_path(:,1))-grid_width_rest*(1-j1*slide_width):grid_width_rest:max(smooth_path(:,1))+grid_width_rest;
        X = discretize(smooth_path(:,1),x0);
        y0 = min(smooth_path(:,2))-grid_width_rest*(1-j2*slide_width):grid_width_rest:max(smooth_path(:,2))+grid_width_rest;
        Y = discretize(smooth_path(:,2),y0);
        V = diff(X).^2+diff(Y).^2;
        tmp = binary_to_duration(V>0);
        tmp = tmp(tmp(:,3)==0,:);
        for g = 1:size(tmp,1)
               T(tmp(g,1):tmp(g,2)+1,w) = tmp(g,4);
        end
        w = w+1;
    end
end

[max_T,~] = max(T,[],2);
max_T_rest = max_T < N_least;
tmp = binary_to_duration(max_T_rest);
tmp = tmp(tmp(:,3)==0,:);
REST = tmp;

%% plot the example
    index = ones(size(path,1),1);
    for i = 1:size(tmp,1)
            index(tmp(i,1):tmp(i,2)) = 0; 
    end
    kw = find(index == 0); 
    figure('position',[100,800,700,300])
    plot(smooth_path(:,1),'b.')
    hold on
    plot(kw,smooth_path(kw,1),'r.')
    plot(smooth_path(:,2),'k.')
    plot(kw,smooth_path(kw,2),'r.')
    set(gca,'fontsize',14,'linewidth',1.5)
    legend('x','x-rest','y','y-rest','location','eastoutside')
    
end
