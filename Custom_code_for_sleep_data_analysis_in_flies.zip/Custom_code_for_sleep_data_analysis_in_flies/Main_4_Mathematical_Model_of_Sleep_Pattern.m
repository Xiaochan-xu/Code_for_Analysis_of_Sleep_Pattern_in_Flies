%% Main code for Methamatical Model
%% mathematical model simulation
% first process: power law area, next process: exponential area

%% 2-D with sleep area
L = 50; % Number of state
total_sample = 20000;% Number of repeats of random walking
time_record = zeros(total_sample,1);
w = 0.3;
r = 20000; % 1 / epsilon in sleep area
a = 0.9;

% 1:left 2:right 3:up 4:down
pre_step = [-1,0;1,0;0,-1;0,1];
P_edge = [0,0.25,0.5,0.75,1];

index_M = ones(L,L);
for i = 1:L
    for j = 1:L
        if i> w*(2*L)-j
            index_M(i,j) = 0;
        end
    end
end

count = 1;
while count <= total_sample
%       count
      state = [1,1];
      tmp = 1;
      while all(state>0) && all(state <= L)
          step = [0,0];
          z = rand(1);
          h = discretize(z,P_edge);
          step = pre_step(h,:);
          if sum(state) > (2*L*w)
              tmp = tmp+exprnd(r);
               break
          end
          state = state + step;
          tmp = tmp+exprnd(norm(state)^a);
      end
      time_record(count,1) = tmp;
      count = count+1;
end
%
time_record(:,1) = time_record(:,1)*0.1;
%% plot simulated distribution
close all
mz = 4;
[y_c,sur] = ecdf(time_record);
sur(:,3) = 1-y_c;

figure('color','w','position',[100,800,600,600])
subplot(2,2,1)
loglog(sur(:,1),sur(:,3),'bo','markersize',mz)
hold on
xlim([0.1,10000])
set(gca,'fontsize',14,'linewidth',1.5)
set(gca,'ytick',[0.0001,0.01,1],'yticklabel',{'10^{-4}','10^{-2}','10^{0}'})
set(gca,'xtick',[1,100,10000],'xticklabel',{'10^{0}','10^{2}','10^{4}'})
box on
xlabel('Rest time (s)')
ylabel('Probability')

subplot(2,2,2)
semilogy(sur(:,1),sur(:,3),'bo','markersize',mz)
hold on
xlim([0,9000])
ylim([0.00005,1])
set(gca,'fontsize',14,'linewidth',1.5)
set(gca,'ytick',[0.0001,0.01,1],'yticklabel',{'10^{-4}','10^{-2}','10^{0}'})
set(gca,'xtick',[0,4000,8000],'xticklabel',[0,4000,8000])
box on
set(gca,'fontsize',14)
xlabel('Rest time (s)')
ylabel('Probability')