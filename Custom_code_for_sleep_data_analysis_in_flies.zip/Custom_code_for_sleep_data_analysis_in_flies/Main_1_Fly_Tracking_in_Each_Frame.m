%% Main code for fly tracking in each frame.
% use mean of 12 hours
close all
BG = {};

tspan = [1,12];
test_id = 12; % test example

clear example
for i = tspan(1):tspan(2)
   tmp1 = imread(['./example_datasets/BG_figure/bg',num2str(i),'.jpg']);
   tmp1 = double(tmp1(:,:,1)); 
   BG{i} =  tmp1;
end
BG0 = BG{tspan(1)};
for i = tspan(1)+1:tspan(2)
    BG0 = BG0 + BG{i};
end
BG0 = BG0/(tspan(2)-tspan(1)+1);
disp('Calculated BG with mean method')

% load the observing areas
load('./example_datasets/BG_figure/specific_location.mat');
loc = specific_location;
example.BG0 = BG0;

a1 = BG{test_id};
fly_id = 1:14;
example.current = a1;

%%
% plot original figure
clear h
figure('position',[100,800,400,300])
for i = fly_id
    h(i) = subplot(2,7,i);
    imshow(a1(loc(i,2):loc(i,4),loc(i,1):loc(i,3))/255);  
end
set_position_14_subfigures;
suptitle('Original Subfigures')

% plot background figure
clear h
figure('position',[100,800,400,300])
for i = fly_id
    h(i) = subplot(2,7,i);
    imshow(BG0(loc(i,2):loc(i,4),loc(i,1):loc(i,3))/255);  
end
set_position_14_subfigures;
suptitle('Reconstructed Background');

%% imopen background figure
se = strel('disk',3);
BGX = imopen(BG0,se);
CCh = bwconncomp(BGX >= fore_th);
S = regionprops(CCh);
if CCh.NumObjects > 1
   pp = cat(1,S.Area);
   [~,id] = max(pp);
   D0 = BGX;
   D0(:,:) = 0;
   D0(CCh.PixelIdxList{id}) = 1;
end
BGX = BGX.*D0;

%% plot imopen background figure 
figure('position',[100,800,400,300])
clear h
for i = fly_id
   h(i) = subplot(2,7,i);
   bgx0 = BGX(loc(i,2):loc(i,4),loc(i,1):loc(i,3));
   imshow(bgx0/255);
end
set_position_14_subfigures;
example.BGX = BGX;
suptitle('Imopen Background')
%% find active zone from the imopen background
fore_th = 100; % threshold for active zone from background
example.BGX_bina = BGX>=fore_th;

% distribution of grey value
figure('position',[100,800,400,300])
legend_str = {};
for i = fly_id  
   bgx = BGX(loc(i,2):loc(i,4),loc(i,1):loc(i,3));
   [m,n] = hist(bgx(:),100);
   plot(n,m)
   legend_str{i} = ['Area ',num2str(i)];
   hold on
end
ylim([0,3500])
plot([fore_th,fore_th],[0,3500],'k--','linewidth',2)
xlabel('Intensity value');
ylabel('Number of pixels')
legend(legend_str,'Location','eastoutside')
set(gca,'linewidth',2,'xtick',0:50:250,'xticklabel',0:50:250,'ytick',0:1000:3000,'yticklabel',0:1000:3000,'fontsize',14)
xlim([0,256])
box off
%% difference image 

tmp = [a1(:),BG0(:)];
tmp = quantilenorm(tmp);
d1 = reshape(tmp(:,1)-tmp(:,2), size(a1)); 

% plot difference image for tracing
figure('position',[100,800,400,300])
clear h
for i = fly_id  
   h(i) = subplot(2,7,i);
   d0 = d1(loc(i,2):loc(i,4),loc(i,1):loc(i,3));
   imagesc(d0,[-20,100])
   axis off
end
set_position_14_subfigures;
suptitle('Difference Image')

example.real_diff = d1;


d1 = d1.* (BGX < fore_th);
example.in_diff = d1;

%% plot difference image for tracing after filtering
figure('position',[100,800,400,300])
clear h
example.tracing_results= {};
example.fly_loc = zeros(14,2);
for i =  fly_id
h(i) = subplot(2,7,i);
d0 = d1(loc(i,2):loc(i,4),loc(i,1):loc(i,3));
d0 = d0.*(d0 > 0);
d0 = medfilt2(d0);
d0 = imfilter(d0,ones(3)/9, 'symmetric');
[~,I] = sort(d0(:),'descend');
d0(I(101:end)) = 0;

example.tracing_results{i} = d0;
imagesc(d0,[-20,100])

hold on
[cy,cx] = FindMaxArea_light(d0,a1(loc(i,2):loc(i,4),loc(i,1):loc(i,3)));
if cy > 0
plot(cy,cx,'r.','markersize',5)
example.fly_loc(i,1:2)= [cy,cx];
end

axis tight
axis off
end 
set_position_14_subfigures;
suptitle('Flies Detected  (n = 14)')
