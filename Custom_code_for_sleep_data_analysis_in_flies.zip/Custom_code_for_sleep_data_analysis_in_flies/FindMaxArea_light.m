function [cy,cx ] = FindMaxArea_light(d0,im)
cy = 0;
cx = 0;
d00 = d0 > 5;
CCh = bwconncomp(d00);
if CCh.NumObjects > 0
pp = zeros(CCh.NumObjects,1);
for i = 1:CCh.NumObjects
    pp(i) =mean( d0(CCh.PixelIdxList{i}));
end
    [~,id] = max(pp);
    d0(:,:) = 0;
    CCh.PixelIdxList{id};
    d0(CCh.PixelIdxList{id}) = 1;
    d0 = d0.*im;
    s_all = sum(sum(d0));
    cy = dot(sum(d0),1:size(d0,2))/s_all;
    cx = dot(sum(d0,2),1:size(d0,1))/s_all;
end
end
