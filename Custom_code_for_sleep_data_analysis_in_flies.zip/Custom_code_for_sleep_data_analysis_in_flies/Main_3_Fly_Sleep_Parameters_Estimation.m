%% Main code for estimation of sleep pattern parameters

function [para] = Main_3_Fly_Sleep_Parameters_Estimation(REST)
frms = 25; % frame rate
load('./example_datasets/REST.mat');
day = REST(:,4);
day = day/frms;
[y_day,L_day] = ecdf(day);
y_day = 1-y_day;

[alpha, xmin, L] = plfit(day,'xmin',3);
para = [alpha, xmin, L];

[N_exp, r_exp, k_exp] = exp_fit(day);
para = [para, N_exp, r_exp, k_exp]; 
para(1) = para(1)-1;
%% plot distribution
close all
figure('position',[100,800,800,250])
subplot(1,2,1)
plot(L_day,y_day,'.-','color','b','markersize',12)
hold on
box off
set(gca,'xscale','log')
set(gca,'yscale','log')
set(gca,'fontsize',14, 'linewidth',1.5)
set(gca,'xtick',[1,100,10000],'xticklabel',{'10^0','10^2','10^4'})
set(gca,'ytick',[0.0001,0.01,1],'yticklabel',{'10^{-4}','10^{-2}','10^0'})
xlabel('Rest time (s)')
ylabel('Probability')

subplot(1,2,2)
plot(L_day,y_day,'.-','color','b','markersize',12)
hold on
box off
set(gca,'yscale','log')
set(gca,'fontsize',14, 'linewidth',1.5)
set(gca,'ytick',[0.0001,0.01,1],'yticklabel',{'10^{-4}','10^{-2}','10^0'})
xlabel('Rest time (s)')
ylabel('Probability')
end

function [N_exp, r_exp, k_exp] = exp_fit(data)
N_exp = 0;
r_exp = 0;
k_exp = 0;
[data0,~] = sort(data,'ascend');
for i = 50:data0(end-20)
    datax = data;
    datax = datax(datax>i);
    datax = datax-i;
    muhat = expfit(datax);
    testcdf = [datax,expcdf(datax,muhat)];
    H = kstest(datax,'CDF',testcdf,'Alpha',0.1);
    if H == 0
       N_exp = length(datax);
       r_exp = muhat;
       k_exp = i;
       break
    end
end

end
